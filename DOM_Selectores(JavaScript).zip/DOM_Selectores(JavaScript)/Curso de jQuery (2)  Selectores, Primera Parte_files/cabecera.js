jQuery(function( $ ){
    
	function fade_home_top() {
            if ( $(window).width() > 800 ) {
                window_scroll = $(this).scrollTop();
                    $("h1, .boton-inicio").css({'opacity' : 1-(window_scroll/300)});
		}
	}
	$(window).scroll(function() { fade_home_top(); });
	
});

